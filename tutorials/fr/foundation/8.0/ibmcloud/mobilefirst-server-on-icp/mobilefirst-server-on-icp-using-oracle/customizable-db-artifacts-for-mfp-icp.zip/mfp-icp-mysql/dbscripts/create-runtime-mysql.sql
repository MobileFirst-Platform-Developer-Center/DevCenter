--
-- Licensed Materials - Property of IBM
-- 5725-I43 (C) Copyright IBM Corp. 2011, 2016. All Rights Reserved.
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
--

-- This script creates the tables in the Worklight database,
-- when the database management system is MySQL.

-- BEFORE executing this script, you have to have an empty database
-- for Worklight.
-- IBM MobileFirst Platform documentation, section
-- Installing and configuring
-- > Installing IBM MobileFirst Platform Server
--    > Installing MobileFirst Server for a production environment
--       > Setting up databases
--          > Relational databases
--             > Create the database tables manually
--                > Creating the MySQL database tables manually

-- To execute this script:
-- Let's assume
--   the database name is "WRKLGHT",
--   the user is named wluser,
--   and the database runs on 192.168.178.38.
-- Log in with the mysql interpreter:
-- mysql -u wluser -p -h 192.168.178.38 WRKLGHT
-- It will ask for the password of wluser. Then type on its command line:
-- source create-runtime-mysql.sql;
-- quit;

CREATE TABLE LICENSE_TERMS (ID BIGINT NOT NULL AUTO_INCREMENT, ACT_DEVICES BIGINT NOT NULL, APP_COUNT BIGINT NOT NULL,
                                INACT_DEVICES BIGINT NOT NULL, REPORT_TIME TIMESTAMP NOT NULL, SERVER_COUNT BIGINT NOT NULL,
                                PRIMARY KEY (ID)) ENGINE = innodb;
CREATE TABLE ADDRESSABLE_DEVICE (REPORT_TIME TIMESTAMP NOT NULL, APP_NAME VARCHAR(255) NOT NULL, ADDRESSABLE_COUNT BIGINT NOT NULL,
                                CATEGORY TINYINT, PRIMARY KEY (REPORT_TIME, APP_NAME)) ENGINE = innodb;

CREATE TABLE MFP_TRANSIENT_DATA (ID VARCHAR(128) NOT NULL, VALUE MEDIUMTEXT NOT NULL, EXPIRESAT BIGINT NOT NULL,
                                HASH VARCHAR(30) NOT NULL, PRIMARY KEY (ID)) ENGINE = innodb;
CREATE TABLE MFP_PERSISTENT_DATA (ID VARCHAR(64) NOT NULL, VALUE MEDIUMTEXT NOT NULL, DEVICE_ID VARCHAR(128) NOT NULL,
                                DEVICE_DISPLAY_NAME VARCHAR(128), DEVICE_STATUS SMALLINT NOT NULL, APPLICATION_ID VARCHAR(128) NOT NULL,
                                APPLICATION_VERSION VARCHAR(128) NOT NULL, CLIENT_STATUS SMALLINT NOT NULL, ASSOCIATED_USERS VARCHAR(1500),
                                LAST_ACTIVITY_TIME BIGINT NOT NULL, HASH VARCHAR(30) NOT NULL, PRIMARY KEY (ID)) ENGINE = innodb;;
CREATE TABLE MFP_PERSISTENT_CUSTOM_ATTR (ENTITY_ID VARCHAR(64), ATTRIBUTE_NAME VARCHAR(128), ATTRIBUTE_VALUE VARCHAR(255),
                                PRIMARY KEY (ENTITY_ID, ATTRIBUTE_NAME), FOREIGN KEY (ENTITY_ID) REFERENCES MFP_PERSISTENT_DATA (ID) ON DELETE CASCADE) ENGINE = innodb;

CREATE INDEX DEVICE_ID_INDEX on MFP_PERSISTENT_DATA (DEVICE_ID ASC);
CREATE INDEX APPLICATION_ID_INDEX on MFP_PERSISTENT_DATA (APPLICATION_ID ASC);
CREATE INDEX LAST_ACTIVITY_TIME_INDEX on MFP_PERSISTENT_DATA (LAST_ACTIVITY_TIME ASC);
CREATE INDEX CUSTOM_ATTRIBUTES_INDEX on MFP_PERSISTENT_CUSTOM_ATTR (ATTRIBUTE_NAME ASC,ATTRIBUTE_VALUE ASC);


CREATE TABLE SERVER_VERSION (SERVER_VERSION VARCHAR(50) NOT NULL) ENGINE = innodb;
INSERT INTO SERVER_VERSION(SERVER_VERSION) VALUES ('8.0.0');
