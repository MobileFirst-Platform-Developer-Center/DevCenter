--
-- Licensed Materials - Property of IBM
-- 5725-I43 (C) Copyright IBM Corp. 2011, 2016. All Rights Reserved.
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
--

-- This script creates the tables in the Worklight database,
-- when the database management system is Oracle.

-- BEFORE executing this script, you have to have
-- - either an empty database for Worklight, and a user
--   in this database,
-- - or an empty schema for Worklight in an existing database
--   (recall that in Oracle, a schema's name is the user name).
-- For instructions how to create such a database manually, see the
-- IBM MobileFirst Platform documentation, section
-- Installing and configuring
--   > Installing IBM MobileFirst Platform Server
--      > Installing MobileFirst Server for a production environment
--         > Setting up databases
--            > Relational databases
--               > Create the database tables manually
--                  > Creating the Oracle database tables manually

-- To execute this script:
-- Log in to the database server.
-- Let's assume
--   the database name is WRKLGHT,
--   and you are using the database user WRKUSER.
-- Execute sqlplus and connect to the specified user in the database:
-- sqlplus WRKUSER@WRKLGHT
-- Then type on its command line:
-- start create-runtime-oracle.sql;
-- quit;

CREATE TABLE LICENSE_TERMS (ID NUMBER(19,0) NOT NULL, ACT_DEVICES NUMBER(19,0) NOT NULL, APP_COUNT NUMBER(19,0) NOT NULL,
                                INACT_DEVICES NUMBER(19,0) NOT NULL, REPORT_TIME TIMESTAMP NOT NULL, SERVER_COUNT NUMBER(19,0) NOT NULL, PRIMARY KEY (ID));
CREATE TABLE ADDRESSABLE_DEVICE (REPORT_TIME TIMESTAMP NOT NULL, APP_NAME VARCHAR(255) NOT NULL, ADDRESSABLE_COUNT NUMBER(19,0) NOT NULL,
                                CATEGORY NUMBER, PRIMARY KEY (REPORT_TIME, APP_NAME));

CREATE TABLE MFP_TRANSIENT_DATA (ID VARCHAR(128) NOT NULL, VALUE CLOB NOT NULL, EXPIRESAT NUMBER(19,0) NOT NULL,
                                HASH VARCHAR(30) NOT NULL, PRIMARY KEY (ID));
CREATE TABLE MFP_PERSISTENT_DATA (ID VARCHAR(64) NOT NULL, VALUE CLOB NOT NULL, DEVICE_ID VARCHAR(128) NOT NULL,
                                DEVICE_DISPLAY_NAME VARCHAR(128), DEVICE_STATUS NUMBER(5,0) NOT NULL, APPLICATION_ID VARCHAR(128) NOT NULL,
                                APPLICATION_VERSION VARCHAR(128) NOT NULL, CLIENT_STATUS NUMBER(5,0) NOT NULL, ASSOCIATED_USERS VARCHAR(1500),
                                LAST_ACTIVITY_TIME NUMBER(19,0) NOT NULL, HASH VARCHAR(30) NOT NULL, PRIMARY KEY (ID));
CREATE TABLE MFP_PERSISTENT_CUSTOM_ATTR (ENTITY_ID VARCHAR(64), ATTRIBUTE_NAME VARCHAR(128), ATTRIBUTE_VALUE VARCHAR(256),
                                PRIMARY KEY (ENTITY_ID, ATTRIBUTE_NAME), FOREIGN KEY (ENTITY_ID) REFERENCES MFP_PERSISTENT_DATA (ID) ON DELETE CASCADE);

CREATE INDEX DEVICE_ID_INDEX on MFP_PERSISTENT_DATA (DEVICE_ID ASC, ID ASC);
CREATE INDEX APPLICATION_ID_INDEX on MFP_PERSISTENT_DATA (APPLICATION_ID ASC, ID ASC);
CREATE INDEX LAST_ACTIVITY_TIME_INDEX on MFP_PERSISTENT_DATA (LAST_ACTIVITY_TIME ASC, ID ASC);
CREATE INDEX CUSTOM_ATTRIBUTES_INDEX on MFP_PERSISTENT_CUSTOM_ATTR (ATTRIBUTE_NAME ASC,ATTRIBUTE_VALUE ASC);

CREATE TABLE SERVER_VERSION (SERVER_VERSION VARCHAR(50) NOT NULL);
INSERT INTO SERVER_VERSION(SERVER_VERSION) VALUES ('8.0.0');

CREATE SEQUENCE LICENSE_TERMS_ID_SEQUENCE
  MINVALUE 0
  START WITH 1
  INCREMENT BY 1;