--<ScriptOptions statementTerminator=";"/>

CREATE PROCEDURE POPULATEDB ()
	DYNAMIC RESULT SETS 1
P1: BEGIN
	-- Declare cursor
	DECLARE COUNT INT DEFAULT 399999;
    DECLARE N INT DEFAULT 500001;
	DECLARE cursor1 CURSOR WITH RETURN for
	-- #######################################################################
	-- # Replace the SQL statement with your statement.
	-- #  Note: Be sure to end statements with the terminator character (usually ';')
	-- #
	-- # The example SQL statement SELECT NAME FROM SYSIBM.SYSTABLES
	-- # returns all names from SYSIBM.SYSTABLES.
	-- ######################################################################
	select count(*) from CLIENT_INSTANCES;
WHILE COUNT < N DO
SET COUNT = COUNT + 1;
insert into CLIENT_INSTANCES values (count ,'test','1.0','ANDROID',blob(x'30819F300D06092A864886F70D010101050003818D00308189028181009A8757DC39A58B28210FC8367385B2920C02C647C4A82411FFD5B0C0B60985EAE4A785760D1CB8213E01B1AABBA4D71031D769387F62D501690CF4E870D9A8E78A9A613E112CA9759B40C4F839E84E502880EEA56B5A316971C3E7D270A003DF4453FC4FC69247DD2B7204724599D60335B6F542C7FDD84380B1B7183E23A2C90203010001'),count,'Android-4.2.2','Lenovo S750');
end while;
	-- Cursor left open for client application
	OPEN cursor1;
END P1;

